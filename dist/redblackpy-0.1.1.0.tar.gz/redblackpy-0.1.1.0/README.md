# RedBlackPy
Fast and Scalable Data Structures for Scientific and Quantitative Research.

Now available only beta version from 'beta' brucnh. To setup run in command line
```bash
python setup.py install
```
