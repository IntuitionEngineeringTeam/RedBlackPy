#
#  Created by Soldoskikh Kirill.
#  Copyright 2018 Intuition. All rights reserved.
#

TYPES = [ 'uint8_t', 'uint16_t', 'uint32_t', 'uint64_t','uint96_t', 'uint128_t',
          'int8_t', 'int16_t', 'int32_t', 'int64_t', 'int96_t', 'int128_t',
          'float32_t', 'float64_t', 'float80_t', 'float96_t', 'float128_t',
          'object' ]
